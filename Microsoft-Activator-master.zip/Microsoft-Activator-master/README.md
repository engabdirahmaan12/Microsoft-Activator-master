<h1>Microsoft-Activator</h1>

<h2><center> Activate Your Windows 
And Microsoft Office  For free.</center></h2>
<h3><center> Run this file as administer</center></h3>

<center><h3> You can activate</h3></center>
<hr>

<center><h3> Microsoft Office 2010</h3></center>
<center>
Microsoft Office 2010 Standard Volume<br>
Microsoft Office 2010 Professional Plus Volume
</center>
<hr>
<center><h3>Microsoft Office 2013</h3></center>
<center>
Microsoft Office 2013 Standard Volume<br>
Microsoft Office 2013 Professional Plus Volume
</center>
<hr>
<center><h3>Microsoft Office 2010</h3></center>
<center>
Microsoft Office Standard<br> 
Microsoft Office Professional Plus 2019<br>
<center>

<hr>
<center><h3>Windows 7</h3></center>
<center>
Windows 7 Professional<br>
Windows 7 Professional N<br>
Windows 7 Professional E<br>
Windows 7 Enterprise<br>
Windows 7 Enterprise N<br>
Windows 7 Enterprise E<br>
</center>
<hr>
<center><h3>Windows 8</h3></center>
<center>
Windows 8 Core<br>
Windows 8 Core Single Language<br>
Windows 8 Professional<br>
Windows 8 Professional N<br>
Windows 8 Professional WMC<br>
Windows 8 Enterprise<br>
Windows 8 Enterprise N<br>
</center>
<hr>
<center><h3>Windows 8.1</h3></center>
<center>
Windows 8.1 Core<br>
Windows 8.1 Core N<br>
Windows 8.1 Core Single Language<br>
Windows 8.1 Professional<br>
Windows 8.1 Professional N<br>
Windows 8.1 Professional WMC<br>
Windows 8.1 Enterprise<br>
Windows 8.1 Enterprise N<br>
</center>
<hr>
<center><h3>Windows 10</h3></center>
<center>
Windows 10 Home<br>
Windows 10 Home N<br>
Windows 10 Home Single Language<br>
Windows 10 Home Country Specific<br>
Windows 10 Professional<br>
Windows 10 Professional N<br>
Windows 10 Education N<br>
Windows 10 Education N<br>
Windows 10 Enterprise<br>
Windows 10 Enterprise N<br>
Windows 10 Enterprise LTSB<br>
Windows 10 Enterprise LTSB<br>
</center>
